package com.codestates.seb.kdelivery;

public class Feedback {
  private String customerName;
  private String shopName;
  private String foodName;
  private int grade;

  /**
   * @Feedback() : 정보를 저장합니다
   */

  /**
   * @getStars() : 사용자가 입력한 점수가 별점으로 전환
   */

  /**
   * @printInfo() : 출력
   */


}
