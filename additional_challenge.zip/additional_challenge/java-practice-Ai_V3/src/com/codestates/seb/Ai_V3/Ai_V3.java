package com.codestates.seb.Ai_V3;

public class Ai_V3 {
  public static void main(String[] args) {
    //TODO:
    /*
     * 프로그램에 필요한 변수 선언
     * xy_lists       : 데이터를 담을 2차원 배열
     * diff           : 편차
     * diff_pow       : 편차의 제곱(double)
     * diff_pow_float : 편차의 제곱(float)
     * sum_diff_pow   : 편차 제곱의 합
     * */

    // 프로그램 안내 문구 출력

    // 1단계 2차원 배열 데이터 생성

    // 데이터 출력 안내 문구 생성

    // 2단계, 3단계
    // 배열 속 값을 호출하며 편차 -> 제곱 -> 합산 과정을 수행합니다.
  }
}
